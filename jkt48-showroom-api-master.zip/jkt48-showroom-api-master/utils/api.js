const HOME = 'https://campaign.showroom-live.com/akb48_sr/data/room_status_list.json';
const BASE_URL = 'https://www.showroom-live.com/api';
const ROOM = `${BASE_URL}/room`;
const LIVE = `${BASE_URL}/live`;

module.exports = { HOME, ROOM, LIVE, BASE_URL }